<?php
$connection = mysqli_connect("localhost", "root", "", "restaurant_management_system");
